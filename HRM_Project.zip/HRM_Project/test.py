from django.contrib.auth.hashers import make_password

print(make_password('aadd1122'))